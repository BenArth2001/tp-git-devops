package com.example.firstwebappgrp1.singleinstance;

import com.example.firstwebappgrp1.service.FilmService;

public class SingleListFilm {
    public static final FilmService filmService = new FilmService();
}
