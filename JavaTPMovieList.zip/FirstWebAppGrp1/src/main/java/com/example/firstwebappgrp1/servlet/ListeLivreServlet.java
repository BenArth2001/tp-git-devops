package com.example.firstwebappgrp1.servlet;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;

@WebServlet(name = "ListeLivres", value = "/liste-livre")
public class ListeLivreServlet extends HttpServlet {
}
